#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <string.h>

float somaDe4Num(){
  float numero, soma = 0;
  for(int i = 0; i < 4; i++){
    printf("Digite um numero: ");
    scanf("%f", &numero);
  soma = soma + numero;
}
printf("A soma dos numeros eh: %.2f", soma);
return soma;
}


int main(void) {
  somaDe4Num();
  return 0;
}